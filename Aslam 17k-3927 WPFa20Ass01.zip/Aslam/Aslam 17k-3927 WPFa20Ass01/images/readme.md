This folder contains the images of the website
